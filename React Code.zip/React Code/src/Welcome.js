import React,{Component} from 'react';
class Welcome extends React.Component{
    constructor(){
        super();
        this.state={
            name:"Swati"};
            this.updateName=this.changeName.bind(this);
    }
    changeName(){
        this.setState({name:"Ashwini"})
    }
render(){
    return(
        <div>
            <Message/>
            <h2>{this.state.name}</h2>
            <button onClick={this.updateName}>Update Name</button>
        </div>
    )
}
}
class Message extends React.Component{
    render(){
        return(
            <div>
                <h1>Welcome to React World!!!!</h1>     
            </div>
        );
    }
}
export default Welcome;