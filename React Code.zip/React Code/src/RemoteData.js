import React,{Component} from 'react';
import axios from 'axios';
class RemoteData extends React.Component {
    constructor(){
        super();
  this.state = {
    isLoading: true,
    users: []
  }
this.updateUsers=this.updateUsers.bind(this);
 
  }
updateUsers(){
    var myArray=this.state.users;
    axios.get("https://jsonplaceholder.typicode.com/users")
        .then(function (response){
            console.log(response.data);
            myArray.push(response.data);
            alert(myArray);
            this.setState({users:myArray}) ;

        });
       
    }
    

  
    render() {

        return(
            <div>
                <button onClick={this.updateUsers}>Show Users</button>
                <table border="1"> 
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>UserName</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    <tbody>
                    {this.state.users.map((user)=><TableC data1={user}></TableC>)}
                    </tbody>


                    
                </table>
            </div>
        );
    }
}
class TableC extends React.Component{
    render(){
        return(
            <tr>
            <td>{this.props.data1.id}</td>
            <td>{this.props.data1.name}</td>
            <td>{this.props.data1.username}</td>
            <td>{this.props.data1.email}</td>
            </tr>
        )
    }
}
export default RemoteData;