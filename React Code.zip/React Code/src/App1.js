import React,{Component} from 'react';

class App1 extends React.Component{
    constructor(){
        super();
        console.log("constructor called");
        this.state={
            num:0
        }
this.updateNumber=this.setNewNumber.bind(this);
    }
    setNewNumber(){
        this.setState({num:this.state.num+1});
    }
    render(){
        return(
            <div>
                <Mynum myNumber={this.state.num}></Mynum>
                <button onClick={this.updateNumber}>Increment Number</button>
            </div>
        )
    }
}

class Mynum extends React.Component{
    componentWillMount(){
        console.log('Component will Mount');
    }
    componentDidMount(){
        console.log('Component did Mount');
    }
    componentWillReceiveProps(newProps){
        console.log('Component will receive props');
    }
    shouldComponentUpdate(newProps,newState){
        return true;
    }
    componentWillUpdate(nextProps,nextState){
        console.log("Component will Update");
    }
    componentDidUpdate(nextProps,nextState){
        console.log("Component did Update");
    }
    componentWillUnmount(){
        console.log("Component will unmount");
    }
    render(){
        return(
            <div>
                <h3>{this.props.myNumber}</h3>
            </div>
        )
    }
}
export default App1;