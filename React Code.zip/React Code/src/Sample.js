import React,{Component} from 'react';

class Sample extends React.Component{
    constructor(){
        super();
        console.log("constructor");
        this.state={
            name:"Swati"
        };
this.updateName=this.updateName.bind(this);
    }
    updateName(){
        this.setState({name:"Ashwini"});
    }
    componentWillMount(){
        console.log('Component will Mount');
    }
    componentDidMount(){
        console.log('Component did Mount');
    }
    componentWillReceiveProps(newProps){
        console.log('Component will receive props');
    }
    shouldComponentUpdate(newProps,newState){
        return true;
    }
    componentWillUpdate(nextProps,nextState){
        console.log("Component will Update");
    }
    componentDidUpdate(nextProps,nextState){
        console.log("Component did Update");
    }
    componentWillUnmount(){
        console.log("Component will unmount");
    }
    render(){
        return(
            <div>
                <h2>Statefull Component</h2>
                <h3>{this.state.name}</h3>
                <button onClick={this.updateName}>Update Name</button>
                <Name myName={this.state.name}/>
            </div>
        )
    }
}
class Name extends React.Component{
    componentWillMount(){
        console.log('Name Component will Mount');
    }
    componentDidMount(){
        console.log('Name Component did Mount');
    }
    componentWillReceiveProps(newProps){
        console.log('Name Component will receive props');
    }
    shouldComponentUpdate(newProps,newState){
        return true;
    }
    componentWillUpdate(nextProps,nextState){
        console.log(" Name Component will Update");
    }
    componentDidUpdate(nextProps,nextState){
        console.log("Name Component did Update");
    }
    componentWillUnmount(){
        console.log("Name Component will unmount");
    }
    render(){
        return(
            <div>
                <h2> {this.props.myName}</h2>
            </div>
        )
    }
}
export default Sample;