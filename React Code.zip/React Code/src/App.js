import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
     <h1>Welcome to React JS!!!!</h1>
    </div>
  );
}

export default App;
