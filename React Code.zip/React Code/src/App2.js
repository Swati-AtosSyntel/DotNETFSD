import React,{Component} from 'react';
import ReactDOM from 'react-dom';
class App2 extends React.Component{
    constructor(){
        super();
        this.state={
            text:''
        }
        this.updateState=this.updateState.bind(this);
        this.Reset=this.Reset.bind(this);
    };
    updateState(e){
        this.setState({text:e.target.value});
    }
    Reset(){
        //this.setState({text:''});
        ReactDOM.findDOMNode(this.refs.text1).focus();

    }
    render(){
        return(
            <div>
                <input type="text" value={this.state.text} onChange={this.updateState} ref="text1">

                </input>
                <button onClick={this.Reset}>Reset</button>
                <h4>{this.state.text}</h4>
            </div>
        )
    }
}
export default App2;