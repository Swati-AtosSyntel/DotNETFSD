import React,{Component} from 'react';

class Employee extends React.Component{
    constructor(){
        super();
        this.state={
            data:[
                {"id":"123","name":"Swati"},
                {"id":"124","name":"Manisha"},
                {"id":"125","name":"Ankita"},
            ]
        };
    }
    render(){
        return(
            <div>
                
                <ul>
                    {this.state.data.map((e)=><List items={e}/>)}
                    {this.state.data.map((e)=><li>{e.name}</li>)}
                </ul>
            </div>
        )
    }
}
class List extends React.Component{
    render(){
        var style1={
            color:'Blue'
        };
        return(
            <ul>
                <li style={style1}>{this.props.items.id}--{this.props.items.name}</li>
            </ul>
        )
    }
}

export default Employee;