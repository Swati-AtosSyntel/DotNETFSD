import React,{Component} from 'react';

class Employee1 extends React.Component{
    constructor(){
        super();
        this.state={
            data:[
                {id:123,name:"Swati"},
                {id:124,name:"Omkar"},
                {id:125,name:"Anniruddha"},
                {id:126,name:"Mayuri"},
            ]
        }
    }
    render(){
        return(
            <div>
                <ul>
                    {this.state.data.map((e)=><li>{e.name}</li>)}
                </ul>
                <hr/>
                <table border="1">
                    <thead>
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                    </thead>
                    <tbody>
                        {this.state.data.map((e)=><TableComponent items={e}></TableComponent>)}
                    </tbody>
                    </table>
            </div>
        )
    }
}
export default Employee1;

class TableComponent extends React.Component{
    render(){
        return(
            <tr>
            <td>{this.props.items.id}</td>
            <td>{this.props.items.name}</td>
            </tr>
            
        )
    }
}